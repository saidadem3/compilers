# Dalio, Brian A.
# dalioba
# 2019-02-26
#---------#---------#---------#---------#---------#--------#
class LexicalError( Exception )   : pass
class SyntacticError( Exception ) : pass

#---------#---------#---------#---------#---------#--------#
